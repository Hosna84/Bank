

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String input;
        Scanner scanner = new Scanner(System.in);
        while (true) {
            input = scanner.nextLine().trim();

            String regexForAddingCustumers = "Add a customer with name (?<personName>.*) and (?<initialMoney>.*) unit initial money\\.";
            Matcher matcher = getMatcher(input, regexForAddingCustumers);
            if (matcher.matches()) {
                String name = matcher.group("personName");
                double moneyInSafe = Integer.parseInt(matcher.group("initialMoney"));
                Customer newCustomer = new Customer(name, moneyInSafe);
            }
            String regexForCreatingBank = "Create bank (?<bankName>.*).";
            matcher = getMatcher(input, regexForCreatingBank);
            if (matcher.matches()) {
                String name = matcher.group("bankName");
                Bank newBank = new Bank(name);
            }
            String regexForCreatingBankAccount = "Create a (?<noeHesab>KOOTAH|BOLAN|VIZHE) account for (?<personName>.*) in (?<bankName>.*), with duration (?<duration>.*) and initial deposit of (?<firstSeporde>.*)\\.";
            matcher = getMatcher(input, regexForCreatingBankAccount);
            if (matcher.matches()) {
                String noeHesab = matcher.group("noeHesab");
                String personName = matcher.group("personName");
                String bankName = matcher.group("bankName");
                int duration = Integer.parseInt(matcher.group("duration"));
                int firstSeporde = Integer.parseInt(matcher.group("firstSeporde"));
                if (Bank.isThereBankWithName(bankName)) {
                    if (firstSeporde > Customer.getCustomerByName(personName).getMoneyInSafe()) {

                        System.out.println("Boro baba pool nadari!");
                        continue;
                    } else {
                        Bank bank = Bank.getBankByName(bankName);
                        Customer customer = Customer.getCustomerByName(personName);
                        int interest = Bank.getAccountInterestFromName(noeHesab);
                        //System.out.println(interest);
                        customer.createNewAccount(bank, firstSeporde, duration, interest);

                    }
                } else {
                    System.out.println("In dige banke koodoom keshvarie?");
                    continue;
                }

            }
            String regexForGivingAllMoney = "Give (?<personName>.*)'s money out of his account number (?<accountNumber>.*)\\.";
            matcher = getMatcher(input, regexForGivingAllMoney);
            if (matcher.matches()) {
                String personName = matcher.group("personName");
                int id = Integer.parseInt(matcher.group("accountNumber"));
                Customer customer = Customer.getCustomerByName(personName);
                customer.leaveAccount(id);

            }
            String regexForGivingLoan = "Pay a (?<unitOfLoan>.*) unit loan with %(?<interest>.*) interest and (?<loanDuration>6|12) payments from (?<bankName>.*) to (?<personName>.*)\\.";
            matcher = getMatcher(input, regexForGivingLoan);
            if (matcher.matches()) {
                int amount = Integer.parseInt(matcher.group("unitOfLoan"));
                int interest = Integer.parseInt(matcher.group("interest"));
                int loanDuration = Integer.parseInt(matcher.group("loanDuration"));
                String bankName = matcher.group("bankName");
                String personName = matcher.group("personName");
                if (Bank.isThereBankWithName(bankName)) {
                    Customer customer = Customer.getCustomerByName(personName);
                    customer.getLoan(loanDuration, interest, amount);
                } else {
                    System.out.println("Gerefti maro nesfe shabi?");
                }

            }
            String regexForGazrKardanTime = "Pass time by (?<gozarKarde>.*) unit\\.";
            matcher = getMatcher(input, regexForGazrKardanTime);
            if (matcher.matches()) {
                int gozarKarde = Integer.parseInt(matcher.group("gozarKarde"));
                for (int i = 0; i < gozarKarde; i++) {

                    passMonth();
                }

            }
            String regexForHowMuchMoneySheHas = "Print (?<personName>.*)'s GAVSANDOOGH money\\.";
            matcher = getMatcher(input, regexForHowMuchMoneySheHas);
            if (matcher.matches()) {
                String name = matcher.group("personName");
                Customer customer = Customer.getCustomerByName(name);
                System.out.println((int) customer.getMoneyInSafe());
            }
            String regexForGettingNomreManfi = "Print (?<personName>.*)'s NOMRE MANFI count\\.";
            matcher = getMatcher(input, regexForGettingNomreManfi);
            if (matcher.matches()) {
                String name = matcher.group("personName");
                Customer customer = Customer.getCustomerByName(name);
                System.out.println(-(int) customer.getNegativeScore());
            }
            String regexForCheckingAccountInABank = "Does (?<personName>.*) have active account in (?<bankName>.*)\\?";
            matcher = getMatcher(input, regexForCheckingAccountInABank);
            if (matcher.matches()) {
                String name = matcher.group("personName");
                String bankName = matcher.group("bankName");
                Bank bank = Bank.getBankByName(bankName);
                Customer customer = Customer.getCustomerByName(name);
                if (customer.hasActiveAccountInBank(bank)) System.out.println("yes");
                else System.out.println("no");
            }
            String regexForendingThisHell = "Base dige, berid khonehatoon\\.";
            matcher = getMatcher(input, regexForendingThisHell);
            if (matcher.matches()) break;
        }
    }
    private static Matcher getMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(input);
    }
    private static void passMonth() {
        Loan.passMonth();
        Account.passMonth();
    }
}