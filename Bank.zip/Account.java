

import java.util.ArrayList;

public class Account {
    private static ArrayList<Account> allAccounts = new ArrayList<>();
    private Bank bank;
    private int id;
    private int money;
    private int remainingDuration;
    private int interest;
    private Customer customer;
    public Account(Bank bank, Customer customer, int id, int money, int duration, int interest){
        this.bank = bank;
        this.customer = customer;
        this.id = id;
        this.money = money;
        this.remainingDuration = duration;
        this.interest = interest;
        allAccounts.add(this);
    }
    public Bank getBank(){
        return this.bank;
    }
    public int getId(){
        return this.id;
    }
    public void deleteAccount(Account account){
        allAccounts.remove(account);
    }
    public double getAmountOfMoneyForLeaving(){

       return this.money;
    }
    private void passMonthEach(){
       this.remainingDuration--;
       if(this.remainingDuration<=0){
           this.customer.leaveAccount(this.id);
           double addedMoney = money*((double)interest/100);
           customer.setMoneyInSafe(this.customer.getMoneyInSafe()+addedMoney);
           deleteAccount(this);
       }
    }

    public static void passMonth(){

        ArrayList<Account> copiedList = new ArrayList<>();
        copiedList.addAll(allAccounts);

            for (Account account : copiedList) {
                account.passMonthEach();
        }
    }

}
