
import java.util.ArrayList;

public class Loan {
    private static ArrayList<Loan> allloans = new ArrayList<>();
    private Customer customer;
    private int duration;
    private int remainingpayments;
    private int interest;
    private int amount;
    public Loan(Customer customer, int duration, int interest, int amount){
        this.customer = customer;
        this.duration = duration;
        this.remainingpayments = duration;
        this.interest = interest;
        this.amount = amount;
        allloans.add(this);
    }
    private double getPaymentAmount(){
        double eachPayment = (double)(amount * (1 +(double)interest/100)) /(double)duration;
        //System.out.println(eachPayment);
        return eachPayment;
    }
    public static void passMonth(){
        for(Loan loan : allloans){
            loan.passMonthEach();
        }

    }
    private void passMonthEach(){

        if(this.remainingpayments >0){

               if(this.customer.canPayLoan(this.getPaymentAmount())){

                  this.customer.payLoan(this.getPaymentAmount());
                  this.remainingpayments--;
               }
               else{
                   this.customer.addNegativeScore();
              }

            }

    }

}
