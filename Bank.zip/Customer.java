

import java.util.ArrayList;

public class Customer {
    private static ArrayList<Customer> allCustomers = new ArrayList<>();
    private String name;
    private double moneyInSafe;
    private ArrayList<Account> allActiveAccounts = new ArrayList<>();
    private int totalNumberOfAccountsCreated;
    private int negativeScore;

    public Customer(String name, double moneyInSafe) {
        this.name = name;
        setMoneyInSafe(moneyInSafe);
        this.totalNumberOfAccountsCreated = 0;
        negativeScore = 0;
        allCustomers.add(this);
    }

    public boolean canGetLoan() {
        if (negativeScore <= -5) {
            return false;
        }
        return true;
    }

    public void setMoneyInSafe(double moneyInSafe) {
        this.moneyInSafe = moneyInSafe;
    }

    public static Customer getCustomerByName(String name) {

        for (Customer customer : allCustomers) {
            if (customer.name.equals(name)) {
                return customer;
            }
        }
        return null;
    }

    public double getMoneyInSafe() {

        return this.moneyInSafe;
    }

    public void payLoan(double amount){
        double monyInSafeNew =  this.moneyInSafe -amount;
        setMoneyInSafe(monyInSafeNew);
    }

    public void createNewAccount(Bank bank, int money, int duraion, int interest) {
        totalNumberOfAccountsCreated+=1;
        this.moneyInSafe-=money;
        allActiveAccounts.add(new Account(bank, this, totalNumberOfAccountsCreated, money, duraion, interest));
    }

    public void leaveAccount(int id) {
        Account account = getAccountWithId(id);
        if (account != null) {

            this.moneyInSafe+=account.getAmountOfMoneyForLeaving();
            account.deleteAccount(account);
            allActiveAccounts.remove(account);
        } else System.out.println("Chizi zadi?!");
    }

    private Account getAccountWithId(int id) {
        for (Account account : allActiveAccounts) {

            if (account.getId() == id) {
                return account;
            }
        }

        return null;
    }

    public boolean canPayLoan(double amount){
        if(amount<=this.moneyInSafe){
            return true;
        }
        return false;
    }
    public void addNegativeScore(){
        this.negativeScore-=1;
    }
    public void getLoan(int duration, int interest, int money) {
        if (canGetLoan()) {
            new Loan(getCustomerByName(this.name), duration, interest, money);
            this.moneyInSafe += money;
        }
        else{
            System.out.println("To yeki kheyli vazet bade!");
        }
    }
    public int getNegativeScore(){
        return this.negativeScore;
    }
    public boolean hasActiveAccountInBank(Bank bank){
        for(Account account : allActiveAccounts){
            if(account.getBank().equals(bank)){
                return true;
            }
        }
        return false;
    }
}
