

import java.util.ArrayList;

public class Bank {
    private static ArrayList<Bank> allBanks = new ArrayList<>();
    String name;
    public Bank(String name){
        this.name=name;
        allBanks.add(this);
    }
    public static boolean isThereBankWithName(String name){
        for(Bank bank : allBanks){
            if(bank.name.equals(name)){
                return true;
            }
        }
        return false;
    }
    public static Bank getBankByName(String name){

        for(Bank bank : allBanks){
            if(bank.name.equals(name)){
                return bank;
            }
        }
        return null;
    }
    public static int getAccountInterestFromName(String name){
        if(name.equals("KOOTAH")){
            return 10;
        }
        if(name.equals("BOLAN")){
            return 30;
        }
        if(name.equals("VIZHE")){
            return 50;
        }
        return 0;
    }
}
